<div class="flex flex-wrap justify-center md:space-x-20 ">
    <div class="">
        <img class="w-full h-25 mb-5 mt-5" src="{{ asset('assets/img/logo_kemendes.png') }}">
    </div>
    <div>
        <img class="w-full h-25  mb-5 mt-5" src="{{ asset('assets/img/logo_lapor.png') }}">
    </div>
    <div>
        <img class="w-full h-25  mb-5 mt-5" src="{{ asset('assets/img/logo_portal.png') }}">
    </div>
    <div>
        <img class="w-full h-25  mb-5 mt-5" src="{{ asset('assets/img/logo_jawabarat.png') }}">
    </div>
    <div>
        <img class="w-full h-25  mb-5 mt-5" src="{{ asset('assets/img/logo_KEMENPAREKRAF.png') }}">
    </div>
</div>
