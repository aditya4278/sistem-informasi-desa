<section class="bg-white pt-10 max ">
    <div class=" grid max-w-screen-xl px-4 pt-20 pb-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:pt-28">
        <div class="place-self-center lg:col-span-7">
            <h1 id="slogan"
                class=" text-center font-inter max-w-2xl font-montserrat mb-4 text-4xl font-bold leading-none tracking-tight md:text-5xl xl:text-5xl S">
                Tentang Kami</h1>
        </div>
    </div>
</section>
