<x-Layouts.visitor-layout>
    <x-slot:title>Tentang Kami | </x-slot:title>
    <header>
        <x-partials.frontend.header />
    </header>

    <section class="mx-auto  max-w-7xl">

        <x-partials.frontend.description />
    </section>



</x-Layouts.visitor-layout>
